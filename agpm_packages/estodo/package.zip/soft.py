def refresh():
    loop=300
    while loop >= 0:
        print()
        loop-=1
    global file
    file=open("lst.txt", 'r')
    file.seek(0)
    global lines
    lines=file.readlines()
    for item in lines:
        print(item)
    file.close()
    file=open("lst.txt", 'w')

def addtool():
    usin=input("add: ")
    lines.append(usin+'\n')
    file.seek(0)
    file.writelines(lines)
    file.close()
    refresh()

def removetool():
    usin=input("mark as done: ")
    if usin + '\n' in lines:
        lines.remove(usin+'\n')
        file.seek(0)
        file.writelines(lines)
        file.close
        refresh()
    else:
        print("item not in list")

global file
file=open("lst.txt", 'r')
file.seek(0)
global lines
lines=file.readlines()
for item in lines:
    print(item)
file.close()
file=open("lst.txt", 'w')

while True:
    usin=input(":")
    if usin == "q":
        exit(0)
    elif usin == "add":
        addtool()
    elif usin == "markdone":
        removetool()
    elif usin == "help":
        print("input options: q (quit), add (add item to list), markdone (mark an item as done / remove item from the list)")
    else:
        print("invalid, type 'help' to get list of commands")
