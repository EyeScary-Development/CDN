import os
file_path = os.path.join(os.path.expanduser('~'), '.agpm', 'estodo', 'lst.txt')
lines=[]

def refresh():
    loop=300
    global file_path
    file=open(file_path, 'r')
    file.seek(0)
    global lines
    lines=file.readlines()
    for item in lines:
        print(item)

def write():
    global file_path
    global lines
    file=open(file_path, 'w')
    file.writelines(lines)
    file.close()
    refresh()

def addtool():
    usin=input("add: ")
    lines.append(usin+'\n')
    write()

def removetool():
    usin=input("mark as done: ")
    if usin + '\n' in lines:
        lines.remove(usin+'\n')
        write()
    else:
        print("item not in list")

while True:
    refresh()
    usin=input(":")
    if usin == "q":
        exit(0)
    elif usin == "add":
        addtool()
    elif usin == "markdone":
        removetool()
    elif usin == "help":
        print("input options: q (quit), add (add item to list), markdone (mark an item as done / remove item from the list)")
    else:
        print("invalid, type 'help' to get list of commands")
