import os
script_dir = os.path.dirname(os.path.abspath(__file__))
filename = 'lst.txt'
file_path = os.path.join(script_dir, filename)
global file
file=open(file_path, 'r')
file.seek(0)
global lines
lines=file.readlines()
print("estodo: you have " + len(lines) + " tasks to do")
if len(lines)!=0:
    for item in lines:
        print(item)
else:
    print("", end='')
