import os
file_path=os.path.join(os.path.expanduser('~'), '.agpm', 'estodo', 'lst.txt')

global file
file=open(file_path, 'r')
file.seek(0)
global lines
lines=file.readlines()
print("estodo: you have " + str(len(lines)) + " tasks to do")
if len(lines)!=0:
    for item in lines:
        print(item)
else:
    print("", end='')
